#!/bin/sh
rm -rf release CMakeFiles
rm -rf Makefile build.ninja cmake_install.cmake CMakeCache.txt
