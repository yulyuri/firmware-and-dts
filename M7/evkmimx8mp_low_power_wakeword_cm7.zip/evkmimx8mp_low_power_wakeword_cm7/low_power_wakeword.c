/*
 * Copyright 2021-2022 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"

#include "app.h"
#include "pin_mux.h"
#include "board.h"
#include "app_srtm.h"
#include "low_power_wakeword.h"
#include "lpm.h"
#include "fsl_debug_console.h"
// #include "voice_engine_common.h"   // optional for this bring-up

#include "fsl_device_registers.h"
#include "fsl_mu.h"

/*******************************************************************************
 * Config
 ******************************************************************************/

/* Linux DT shows mailbox at 0x30AA0000. Force MU base to that instance. */
#define MU_BASE_ADDR   (0x30AA0000u)
#define MU_BASE        ((MU_Type *)MU_BASE_ADDR)

/* Make wake obvious while debugging; set back to 1000U later. */
#define MU_WAKE_PERIOD_MS 200U

/* If you discover a specific GIR works best, set FIXED_GIR to 0/1/2/3.
   Leave at -1 to rotate through all four. */
#define FIXED_GIR 1

/*******************************************************************************
 * Prototypes
 ******************************************************************************/
bool LPM_Init(void);

/*******************************************************************************
 * Private data
 ******************************************************************************/
static TimerHandle_t sMuPingTimer = NULL;
static TimerHandle_t sHeartbeat   = NULL;

static const uint32_t s_gir_mask[4] = {
    kMU_GenInt0InterruptTrigger,
    kMU_GenInt1InterruptTrigger,
    kMU_GenInt2InterruptTrigger,
    kMU_GenInt3InterruptTrigger,
};
static const char *s_gir_name[4] = { "GIR0", "GIR1", "GIR2", "GIR3" };

/*******************************************************************************
 * MU helpers (old API)
 ******************************************************************************/
static void MU_Wake_Init(void)
{
    MU_Init(MU_BASE); /* Old API: just enables clock/reset */
    PRINTF("MU base %p init done\r\n", (void*)MU_BASE);
}

/* Fire one GIR and print result */
static void MU_Fire_GIR(int idx)
{
    status_t st = MU_TriggerInterrupts(MU_BASE, s_gir_mask[idx]);
    PRINTF("MU %s -> %s\r\n", s_gir_name[idx], (st == kStatus_Success) ? "OK" : "BUSY");
}

/* Timer callback: rotate GIRs (or use fixed) */
static void mu_timer_cb(TimerHandle_t xTimer)
{
#if (FIXED_GIR >= 0)
    MU_Fire_GIR(FIXED_GIR);
#else
    static int gir = 0;
    MU_Fire_GIR(gir);
    gir = (gir + 1) & 3;
#endif
}

/* Heartbeat so you know the task is alive even if MU gets stuck */
static void heartbeat_cb(TimerHandle_t xTimer)
{
    static uint32_t hb = 0;
    PRINTF("HB %lu\r\n", (unsigned long)++hb);
}

/*******************************************************************************
 * Code
 ******************************************************************************/
void MainTask(void *pvParameters)
{
    PRINTF("Wait the Linux kernel boot up to create the link between M core and A core.\r\n\r\n");

    APP_SRTM_Init();
#if defined(MIMX9352_cm33_SERIES) || defined(MIMX9322_cm33_SERIES) || defined(MIMX9596_cm7_SERIES)
    APP_SRTM_StartCommunication();
#endif

    /* Keep M7 out of STOP so timers keep running */
    LPM_IncreseBlockSleepCnt();

    /* Block here until rpmsg link is up (srtmState == LinkedUp inside LPM_Init). */
    LPM_Init();
    PRINTF("The rpmsg channel between M core and A core created!\r\n\r\n");

    /* Only start MU pings AFTER link-up so Linux clears GIRs */
    MU_Wake_Init();

    /* One-shot probe burst so you can watch /proc/interrupts tick */
    for (int g = 0; g < 4; ++g)
    {
        MU_Fire_GIR(g);
        vTaskDelay(pdMS_TO_TICKS(150));
    }

    /* Start periodic wake timer */
    sMuPingTimer = xTimerCreate("mu_wake",
                                pdMS_TO_TICKS(MU_WAKE_PERIOD_MS),
                                pdTRUE, NULL, mu_timer_cb);
    if (sMuPingTimer) xTimerStart(sMuPingTimer, 0);

    /* Heartbeat every second */
    sHeartbeat = xTimerCreate("hb", pdMS_TO_TICKS(1000), pdTRUE, NULL, heartbeat_cb);
    if (sHeartbeat) xTimerStart(sHeartbeat, 0);

    while (true)
    {
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}

/*!
 * @brief Main function
 */
int main(void)
{
    BOARD_InitHardware();

    PRINTF("\r\n#################### LOW POWER VOICE DEMO bong START ####################\n\r\n");
    PRINTF("Build Time: %s--%s \r\n", __DATE__, __TIME__);

    if (xTaskCreate(MainTask, "Main Task", configMINIMAL_STACK_SIZE,
                    NULL, tskIDLE_PRIORITY + 1U, NULL) != pdPASS)
    {
        PRINTF("Task creation failed!.\r\n");
        while (1) { }
    }

    vTaskStartScheduler();

    for (;;)
    {
    }
}

void vApplicationMallocFailedHook(void)
{
    PRINTF("Malloc Failed!!!\r\n");
}
